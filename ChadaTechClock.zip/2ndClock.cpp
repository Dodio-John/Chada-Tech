#include <iostream>
#include <iomanip>

using namespace std;

//setting the variables to 24 hour time format using Chada Techs functional requirement time
// setting to functional requirements but will be changeable with input
int timeHour = 15; 
// minutes will be changeable but max out at 60
int timeMinutes = 22; 
// seconds will also max out at 60
int timeSeconds = 01; 


//This funciton will verify if the variables fall in the clocks range 
void menuOfTime(bool hour24) {
	if (timeHour < 0 || timeHour > 23 || timeMinutes < 0 || timeMinutes > 59 || timeSeconds < 0 ||
		timeSeconds > 59) {
		return;
	}
	//boolean to distinguish before 12(noon) or AM or after
	bool after12 = timeHour > 12;
#
	int displayHours = after12 && !hour24 ? timeHour - 12 : timeHour;
	// Displays 00 for 12:00 am for 12 hour clock mode
	if (timeHour == 0 && !hour24) {
		displayHours = 12;
	}
	string ampm = "";
	// this will determine if pm is true of false
	if (!hour24) {
		ampm = after12 ? " PM" : " AM";
	}
	// Displays clock and fills 0 before hours between 0-9
	cout << setfill('0');
	cout << setw(2) << displayHours << ":";
	cout << setw(2) << timeMinutes << ":";
	cout << setw(2) << timeSeconds << ampm;
	cout << setfill(' ');
}
void DisplayClocks() {
	cout << "***************** *****************" << endl;
	cout << "* 12-Hour Clock * * 24-Hour Clock *" << endl;
	cout << "* ";
	menuOfTime(false);
	cout << " *   * ";
	menuOfTime(true); 
	cout << endl;
	cout << "***************** *****************" << endl;
}
//Once the user has input their choice this increments the display
//adding time to both clocks
void correctTime() {
	if (timeSeconds >= 60) {
		timeMinutes++;
		timeSeconds = timeSeconds - 60;
	}
	if (timeMinutes >= 60) {
		timeHour++;
		timeMinutes = timeMinutes - 60;
	}
	if (timeHour >= 24) {
		timeHour = timeHour - 24;
	}
}
bool MenuInput(char option) {
	// Adds an hour
	if (option == '1') {
		timeHour++;
	}
	// Adds a minute
	else if (option == '2') {
		timeMinutes++;
	}
	// Adds a second
	else if (option == '3') {
		timeSeconds++;
	}
	// Ends the program if 4 and says goodbye
	else if (option == '4') { 
		cout << "Goodbye" << endl;
		return false;
	}
	//If user does not input 1-4 this will give an invalid entry warning
	else {
		cout << "Invalid entry, try again" << endl;
	}
}
//this will show the user the menu 
bool DisplayMenu() {
	cout << "***************************" << endl;
	cout << "* 1 - Add One Hour *" << endl;
	cout << "* 2 - Add One Minute *" << endl;
	cout << "* 3 - Add One Second *" << endl;
	cout << "* 4 - Exit Program *" << endl;
	cout << "***************************" << endl;
	cout << "Which option would you like to select?" << endl;
	char option;
	cin >> option;
	return MenuInput(option);
}
int main() {
	bool setClock = true;
	//this loop calls the clocks to display until the user choses to exit
	//the loop, each time user adds time the menu will display again
	//with their updated selection
		while (setClock) {
			DisplayClocks();
			setClock = DisplayMenu();
			correctTime();
		}
	return 0;
}




